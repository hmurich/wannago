<span class="step-form__heading">
    Информация о заведении и его владельце
</span>
<div class="form-row">
    <span class="form-row__text">Названия заведения:</span>
    <input type="text" class="form-row__input" name="name">
</div>
<div class="form-row">
    <span class="form-row__text">Адрес:</span>
    <input type="text" class="form-row__input" name="address">
</div>
<div class="form-row">
    <span class="form-row__text">ФИО:</span>
    <input type="text" class="form-row__input" name="fio">
</div>
<div class="form-row">
    <span class="form-row__text">Телефон:</span>
    <input type="text" class="form-row__input" name="phone">
</div>
<div class="form-row">
    <span class="form-row__text">Почта:</span>
    <input type="text" class="form-row__input"  name="email">
</div>
<div class="form-bot">
        <span class="btn form-bot__next step2">Далее</span>
</div>
