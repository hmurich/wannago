<span class="step-form__heading">
    Опишите акции или события<br> которые происходят в вашем заведении
</span>
<div class="form-row">
    <span class="form-row__text">Заголовок:</span>
    <input type="text" class="form-row__input" name="sale_title">
</div>
<div class="form-row">
    <span class="form-row__text">Дата:</span>
    <input type="text" class="form-row__input" name="sale_date">
</div>
<div class="form-row">
    <span class="form-row__text">Описание:</span>
    <textarea type="text" class="form-row__textarea"  name="sale_note"></textarea>
</div>
<div class="form-bot">
    <span class="btn form-bot__left step3">Назад</span>
    <button type="submit" class="btn form-bot__next">Отправить</button>
</div>
