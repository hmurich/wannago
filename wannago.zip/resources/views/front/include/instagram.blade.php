<div class="inner ints-inner">
		<div class="ints-inner__close"></div>
    <img class="logo" src="/front/img/logo.jpg">
    <div class="instagram__text">
        Подписывайся на наш инстаграм: <span>@weekends.kz</span>
    </div>
</div>
