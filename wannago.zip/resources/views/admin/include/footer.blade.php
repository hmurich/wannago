<div class="pull-right hidden-xs">
    <b>Version</b> 2.0.1
</div>
<strong>Copyright &copy; 2017 <a href="http://astanacreative.kz">Astana Creative</a>.</strong> All rights reserved.
