<section class="content-header">
    <h1>
        @yield('title')
        <small>@yield('second_title')</small>
    </h1>
</section>
