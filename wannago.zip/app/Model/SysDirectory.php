<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class SysDirectory extends Model{
    protected $table = 'sys_directory';

    
}
