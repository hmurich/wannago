<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class ObjectScore extends Model{
    protected $table = 'object_score';
    public $timestamps = false;

}
