<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class EventMessage extends Model{
    protected $table = 'event_message';

}
