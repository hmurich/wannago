<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class AnketePhoto extends Model{
    protected $table = 'ankete_photo';
    public $timestamps = false;
    
}
