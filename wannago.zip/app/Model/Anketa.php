<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class Anketa extends Model{
    protected $table = 'anketa';

}
