<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class ObjectLocation extends Model{
    protected $table = 'object_locations';
    public $timestamps = false;

}
