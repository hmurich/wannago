<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class UserForgotPass extends Model{
    protected $table = 'user_forgot_pass';

}
