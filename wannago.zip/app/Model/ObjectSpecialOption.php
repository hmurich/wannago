<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class ObjectSpecialOption extends Model{
    protected $table = 'object_special_options';
    public $timestamps = false;
}
