<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class NewsComment extends Model{
    protected $table = 'news_comment';

}
