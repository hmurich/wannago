<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class ObjectDopOption extends Model{
    protected $table = 'object_dop_options';
    public $timestamps = false;
    
}
