<?php
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class ObjectMainOption extends Model{
    protected $table = 'object_main_option';
    public $timestamps = false;

}
